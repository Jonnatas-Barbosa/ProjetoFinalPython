# Chatbot-for-Biginners

### To run this code
#### Pip install -r requirements.txt
#### python ChatBot.py

Terminal based Chatbot :
![Image of output](https://github.com/datamagic2020/Chatbot-for-Biginners/blob/main/chatbot.png)

UI Based Chatbot :
![Image of output](https://github.com/datamagic2020/Chatbot-for-Biginners/blob/main/ui%20chatbot%20thumb.png)
